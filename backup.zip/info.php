<?php
// You can use Server app to enable the Apache PHP module; it's disabled by default.
// You can uncomment the phpinfo() directive below to provide a default PHP info page
// but note that this displays information about your host's configuration.
//phpinfo();
?>
